<?php
return [
    // 默认控制器名
    'default_controller' => 'index',
    // 默认操作名
    'default_action' => 'index',
];